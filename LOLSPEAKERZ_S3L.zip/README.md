# CMSC 124 - Final Project (LOLCODE Interpreter)

## LOLSPEAKERZ (Group 6)
1. Diocadiz, Gabrielle Therese D.
2. Narvasa, Ricky Vince C.
3. Sumallo, Kurt Princip Gavryl T.

## How To Use
_*The interpreter does not use third-party libraries. No need to install anything._

1. To start the interpreter, simply run `gui.py` in Python.

```
python gui.py
```

2. LOLCODE source code can be loaded from a file (.lol) or entered through the built-in editor.

3. Click the `Execute` button to start running the LOLCODE program.

